# titatic_EDA
In this project I've applied Exploratory Data Analysis techniques to clean our dataset, handle the missing values; Trained and tested the dataset using Logistic Regression thereafter. The dataset used in this project is downloaded from Kaggle: https://www.kaggle.com/competitions/titanic/data.
